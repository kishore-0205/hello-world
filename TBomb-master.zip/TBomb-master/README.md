<h1 align="center">TBomb v1.7b</h1>
<p align="center">An open-source SMS/call bomber for Linux And Termux.</p><br>
![TBomb](https://telegra.ph/file/513ae0817900d3c694ba8.jpg)
## Note:

**Due misusing of TBomb, several API's died.**  
**Don't be afraid if you don't see all send messages.**

- The script requires working network connection to work.
- No balance will be deducted for using this script to send SMS/calls.
- While doing infinite bombing use 2-3 seconds delay and 10 to 20 threads for maximum performance.
- Don't put spaces in between phone number (Ex- 99999 99999)
- Make sure you are using the latest version of TBomb
- Make sure you are using Python3.

Here's how you can check it. Type this command in your terminal.
```
$ python -V
```
If output looks like `Python 3` - Congrats, Python 3 is installed properly.

- Do not use this to harm others.
- This script is only for educational purposes or to prank.
- **None of the developers/contributors are responsible for the misuse of TBomb.**
<br>

## Features:

- Lots of integrated SMS/call APIs
- Unlimited (Limited against abusing) and super-fast bombing
- International bombing available (APIS Dead. Try Your Luck.) 
- Call bombing
- Frequent updates
- Automatic updating mechanism
- Easy to use and embed in code

## Usage:

Run these commands to run TBomb

### > For Termux:

**Notice:** 

git installation methods are not universal and do differ between distributions,
so, installing git as per instructions below may not work.
Please check out how to install `git` for your Linux distribution.
Commands below provide instructions for Debian-based systems.

To use the bomber type the following commands in Termux:
```
pkg install git
pkg install python
git clone https://github.com/QueenArzoo/TBomb.git
cd TBomb
chmod +x TBomb.sh
./TBomb.sh
```

### > For Linux:

**Notice:** 

git installation methods are not universal and do differ between distributions,
so, installing git as per instructions below may not work.
Please check out how to install `git` for your Linux distribution.
Commands below provide instructions for Debian-based systems.

To use the bomber type the following commands in Linux terminal:
```
sudo apt install git
git clone https://github.com/QueenArzoo/TBomb.git
cd TBomb
chmod +x TBomb.sh
sudo bash TBomb.sh
```

### > For macOS:

To use the bomber type the following commands in macOS terminal:
```
# Install Brew: 

/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"

# Install dependencies:

brew install git
brew install python3
sudo easy_install pip
sudo pip install --upgrade pip
git clone https://github.com/QueenArzoo/TBomb.git
cd TBomb
chmod +x TBomb.sh

# Missing Tools on MacOS

Toilet cannot be installed yet. But TBomb does still work.

# Run TBomb:

sudo bash TBomb.sh


